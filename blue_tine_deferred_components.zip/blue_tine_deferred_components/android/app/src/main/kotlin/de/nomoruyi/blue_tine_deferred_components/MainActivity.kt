package de.nomoruyi.blue_tine_deferred_components

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
